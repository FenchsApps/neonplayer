﻿using System;
using System.Windows.Forms;
using NAudio.Wave;
using System.Drawing; // Добавьте эту строку вверху, вместе с другими using
using System.Drawing.Drawing2D; // Для градиентов и GraphicsPath
using TagLib;
using System.IO;

namespace NeonPlayer
{

    public partial class Form1 : Form
    {
        public Image GetAlbumArt(string filePath)
        {
            try
            {
                var file = TagLib.File.Create(filePath);

                // Проверяем наличие обложек
                if (file.Tag.Pictures.Length > 0)
                {
                    var picture = file.Tag.Pictures[0];
                    using (var ms = new MemoryStream(picture.Data.Data))
                    {
                        return Image.FromStream(ms);
                    }
                }
            }
            catch { }

            // Возвращаем иконку по умолчанию, если обложки нет
            return Properties.Resources.DefaultMusicIcon; // Добавьте ресурс в проект
        }

        private WaveStream waveStream;
        private WaveOutEvent outputDevice;
        private string fileName = string.Empty;

        public Form1()
        {

            // Включаем двойную буферизацию для плавного отображения
            this.DoubleBuffered = true;

            // Устанавливаем стиль для перерисовки при изменении размера
            this.SetStyle(ControlStyles.ResizeRedraw, true);
            InitializeComponent();
            outputDevice = new WaveOutEvent(); // Инициализация здесь
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            MakePictureBoxRound(pictureBox1);
            MakePanelRound(panelCover);
            trackBar1.BackColor = Color.FromArgb(40, 40, 40);
            trackBar1.ForeColor = Color.FromArgb(30, 215, 96);
            trackBar1.Height = 5;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (outputDevice == null)
                {
                    outputDevice = new WaveOutEvent();
                }

                if (waveStream != null)
                {
                    outputDevice.Init(waveStream);
                    outputDevice.Play();
                }

                waveStream = new AudioFileReader(fileName);
                outputDevice.Init(waveStream);
                outputDevice.Play();

                // Настройка трекбара
                trackBar1.Maximum = (int)waveStream.TotalTime.TotalSeconds;
                timer1.Start();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"{ex.Message}", "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            outputDevice.Stop();
            timer1.Stop();
        }

        private void открытьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenMedia();
        }

        private void OpenMedia()
        {
            OpenFileDialog oFD = new OpenFileDialog()
            {
                Filter = "Audio Files|*.wav;*.mp3|All files|*.*",
                Multiselect = false,
                ValidateNames = true
            };

            if (oFD.ShowDialog() == DialogResult.OK)
            {
                fileName = oFD.FileName;
                textBox1.Text = fileName;
            }
            OpenFileDialog ofd = new OpenFileDialog();
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                // Загрузка обложки
                picAlbumArt.Image = GetAlbumArt(ofd.FileName);

                // Настройка отображения
                picAlbumArt.SizeMode = PictureBoxSizeMode.Zoom;
                MakePictureBoxRound(picAlbumArt); // Для круглого отображения
            }
        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            if (waveStream != null)
            {
                waveStream.CurrentTime = TimeSpan.FromSeconds(trackBar1.Value);
            }
        }

        private void labelPosition_Click(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (waveStream != null && outputDevice.PlaybackState == PlaybackState.Playing)
            {
                trackBar1.Value = (int)waveStream.CurrentTime.TotalSeconds;
                labelPosition.Text = $"{waveStream.CurrentTime:mm\\:ss} / {waveStream.TotalTime:mm\\:ss}";
            }
        }
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            outputDevice?.Dispose();
            waveStream?.Dispose();
        }
        private void button1_MouseEnter(object sender, EventArgs e)
        {
            playb.BackColor = Color.FromArgb(40, 225, 110); // Светлее при наведении
        }

        private void button1_MouseLeave(object sender, EventArgs e)
        {
            playb.BackColor = Color.FromArgb(30, 215, 96); // Возвращаем стандартный цвет
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
        private void MakePictureBoxRound(PictureBox pictureBox)
        {
            System.Drawing.Drawing2D.GraphicsPath path = new System.Drawing.Drawing2D.GraphicsPath();
            path.AddEllipse(0, 0, pictureBox.Width, pictureBox.Height);
            pictureBox.Region = new Region(path);
        }

        private void MakePanelRound(Panel panel)
        {
            System.Drawing.Drawing2D.GraphicsPath path = new System.Drawing.Drawing2D.GraphicsPath();
            path.AddEllipse(0, 0, panel.Width, panel.Height);
            panel.Region = new Region(path);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);

            // Создаем градиент от темно-серого к черному (как в Spotify)
            using (LinearGradientBrush brush = new LinearGradientBrush(
                this.ClientRectangle,
                Color.FromArgb(40, 40, 40),  // Верхний цвет
                Color.FromArgb(18, 18, 18),   // Нижний цвет
                LinearGradientMode.Vertical))  // Вертикальный градиент
            {
                e.Graphics.FillRectangle(brush, this.ClientRectangle);
            }

            // Дополнительно: можно добавить легкий акцентный градиент
            Rectangle accentRect = new Rectangle(0, 0, this.Width, 10);
            using (LinearGradientBrush accentBrush = new LinearGradientBrush(
                accentRect,
                Color.FromArgb(30, 215, 96),  // Spotify-зеленый
                Color.Transparent,
                LinearGradientMode.Vertical))
            {
                e.Graphics.FillRectangle(accentBrush, accentRect);
            }
        }

    }

}
